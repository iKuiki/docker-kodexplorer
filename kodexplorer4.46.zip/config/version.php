<?php
define('KOD_VERSION','4.46');
define('KOD_VERSION_BUILD','0714');//time(),0409